#!/bin/bash

# Author: A.M.Kharazi
# License: BSD 3 clause

# Comment test cases you wish not to run, then run the bash file

python3 TEST_113.py
python3 TEST_113_val.py
python3 TEST_114.py
python3 TEST_114_val.py
python3 TEST_115.py
python3 TEST_115_val.py
python3 TEST_116.py
python3 TEST_116_val.py
python3 TEST_117.py
python3 TEST_117_val.py
python3 TEST_118.py
python3 TEST_118_val.py
python3 TEST_119.py
python3 TEST_119_val.py
python3 TEST_120.py
python3 TEST_120_val.py
