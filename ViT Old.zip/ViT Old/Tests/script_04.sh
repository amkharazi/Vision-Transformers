#!/bin/bash

# Author: A.M.Kharazi
# License: BSD 3 clause

# Comment test cases you wish not to run, then run the bash file

python3 TEST_025.py
python3 TEST_025_val.py
python3 TEST_026.py
python3 TEST_026_val.py
python3 TEST_027.py
python3 TEST_027_val.py
python3 TEST_028.py
python3 TEST_028_val.py
python3 TEST_029.py
python3 TEST_029_val.py
python3 TEST_030.py
python3 TEST_030_val.py
python3 TEST_031.py
python3 TEST_031_val.py
python3 TEST_032.py
python3 TEST_032_val.py
