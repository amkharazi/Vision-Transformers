#!/bin/bash

# Author: A.M.Kharazi
# License: BSD 3 clause

# Comment test cases you wish not to run, then run the bash file

python3 TEST_057.py
python3 TEST_057_val.py
python3 TEST_058.py
python3 TEST_058_val.py
python3 TEST_059.py
python3 TEST_059_val.py
python3 TEST_060.py
python3 TEST_060_val.py
python3 TEST_061.py
python3 TEST_061_val.py
python3 TEST_062.py
python3 TEST_062_val.py
python3 TEST_063.py
python3 TEST_063_val.py
python3 TEST_064.py
python3 TEST_064_val.py
