#!/bin/bash

# Author: A.M.Kharazi
# License: BSD 3 clause

# Comment test cases you wish not to run, then run the bash file

python3 TEST_089.py
python3 TEST_089_val.py
python3 TEST_090.py
python3 TEST_090_val.py
python3 TEST_091.py
python3 TEST_091_val.py
python3 TEST_092.py
python3 TEST_092_val.py
python3 TEST_093.py
python3 TEST_093_val.py
python3 TEST_094.py
python3 TEST_094_val.py
python3 TEST_095.py
python3 TEST_095_val.py
python3 TEST_096.py
python3 TEST_096_val.py
