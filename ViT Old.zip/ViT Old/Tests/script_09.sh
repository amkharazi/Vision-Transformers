#!/bin/bash

# Author: A.M.Kharazi
# License: BSD 3 clause

# Comment test cases you wish not to run, then run the bash file

python3 TEST_065.py
python3 TEST_065_val.py
python3 TEST_066.py
python3 TEST_066_val.py
python3 TEST_067.py
python3 TEST_067_val.py
python3 TEST_068.py
python3 TEST_068_val.py
python3 TEST_069.py
python3 TEST_069_val.py
python3 TEST_070.py
python3 TEST_070_val.py
python3 TEST_071.py
python3 TEST_071_val.py
python3 TEST_072.py
python3 TEST_072_val.py
