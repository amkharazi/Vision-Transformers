#!/bin/bash

# Author: A.M.Kharazi
# License: BSD 3 clause

# Comment test cases you wish not to run, then run the bash file

python3 TEST_041.py
python3 TEST_041_val.py
python3 TEST_042.py
python3 TEST_042_val.py
python3 TEST_043.py
python3 TEST_043_val.py
python3 TEST_044.py
python3 TEST_044_val.py
python3 TEST_045.py
python3 TEST_045_val.py
python3 TEST_046.py
python3 TEST_046_val.py
python3 TEST_047.py
python3 TEST_047_val.py
python3 TEST_048.py
python3 TEST_048_val.py
