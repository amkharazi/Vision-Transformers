#!/bin/bash

# Author: A.M.Kharazi
# License: BSD 3 clause

# Comment test cases you wish not to run, then run the bash file

python3 TEST_105.py
python3 TEST_105_val.py
python3 TEST_106.py
python3 TEST_106_val.py
python3 TEST_107.py
python3 TEST_107_val.py
python3 TEST_108.py
python3 TEST_108_val.py
python3 TEST_109.py
python3 TEST_109_val.py
python3 TEST_110.py
python3 TEST_110_val.py
python3 TEST_111.py
python3 TEST_111_val.py
python3 TEST_112.py
python3 TEST_112_val.py
