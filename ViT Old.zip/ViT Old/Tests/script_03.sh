#!/bin/bash

# Author: A.M.Kharazi
# License: BSD 3 clause

# Comment test cases you wish not to run, then run the bash file

python3 TEST_017.py
python3 TEST_017_val.py
python3 TEST_018.py
python3 TEST_018_val.py
python3 TEST_019.py
python3 TEST_019_val.py
python3 TEST_020.py
python3 TEST_020_val.py
python3 TEST_021.py
python3 TEST_021_val.py
python3 TEST_022.py
python3 TEST_022_val.py
python3 TEST_023.py
python3 TEST_023_val.py
python3 TEST_024.py
python3 TEST_024_val.py
