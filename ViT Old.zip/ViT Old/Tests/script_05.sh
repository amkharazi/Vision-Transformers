#!/bin/bash

# Author: A.M.Kharazi
# License: BSD 3 clause

# Comment test cases you wish not to run, then run the bash file

python3 TEST_033.py
python3 TEST_033_val.py
python3 TEST_034.py
python3 TEST_034_val.py
python3 TEST_035.py
python3 TEST_035_val.py
python3 TEST_036.py
python3 TEST_036_val.py
python3 TEST_037.py
python3 TEST_037_val.py
python3 TEST_038.py
python3 TEST_038_val.py
python3 TEST_039.py
python3 TEST_039_val.py
python3 TEST_040.py
python3 TEST_040_val.py
