#!/bin/bash

# Author: A.M.Kharazi
# License: BSD 3 clause

# Comment test cases you wish not to run, then run the bash file

python3 TEST_009.py
python3 TEST_009_val.py
python3 TEST_010.py
python3 TEST_010_val.py
python3 TEST_011.py
python3 TEST_011_val.py
python3 TEST_012.py
python3 TEST_012_val.py
python3 TEST_013.py
python3 TEST_013_val.py
python3 TEST_014.py
python3 TEST_014_val.py
python3 TEST_015.py
python3 TEST_015_val.py
python3 TEST_016.py
python3 TEST_016_val.py
