#!/bin/bash

# Author: A.M.Kharazi
# License: BSD 3 clause

# Comment test cases you wish not to run, then run the bash file

python3 TEST_097.py
python3 TEST_097_val.py
python3 TEST_098.py
python3 TEST_098_val.py
python3 TEST_099.py
python3 TEST_099_val.py
python3 TEST_100.py
python3 TEST_100_val.py
python3 TEST_101.py
python3 TEST_101_val.py
python3 TEST_102.py
python3 TEST_102_val.py
python3 TEST_103.py
python3 TEST_103_val.py
python3 TEST_104.py
python3 TEST_104_val.py
