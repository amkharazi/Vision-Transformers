#!/bin/bash

# Author: A.M.Kharazi
# License: BSD 3 clause

# Comment test cases you wish not to run, then run the bash file

python3 TEST_081.py
python3 TEST_081_val.py
python3 TEST_082.py
python3 TEST_082_val.py
python3 TEST_083.py
python3 TEST_083_val.py
python3 TEST_084.py
python3 TEST_084_val.py
python3 TEST_085.py
python3 TEST_085_val.py
python3 TEST_086.py
python3 TEST_086_val.py
python3 TEST_087.py
python3 TEST_087_val.py
python3 TEST_088.py
python3 TEST_088_val.py
