#!/bin/bash

# Author: A.M.Kharazi
# License: BSD 3 clause

# Comment test cases you wish not to run, then run the bash file

python3 TEST_073.py
python3 TEST_073_val.py
python3 TEST_074.py
python3 TEST_074_val.py
python3 TEST_075.py
python3 TEST_075_val.py
python3 TEST_076.py
python3 TEST_076_val.py
python3 TEST_077.py
python3 TEST_077_val.py
python3 TEST_078.py
python3 TEST_078_val.py
python3 TEST_079.py
python3 TEST_079_val.py
python3 TEST_080.py
python3 TEST_080_val.py
