#!/bin/bash

# Author: A.M.Kharazi
# License: BSD 3 clause

# Comment test cases you wish not to run, then run the bash file

# python3 TEST_001.py
# python3 TEST_001_val.py
python3 TEST_002.py
python3 TEST_002_val.py
# python3 TEST_003.py
# python3 TEST_003_val.py
python3 TEST_004.py
python3 TEST_004_val.py
# python3 TEST_005.py
# python3 TEST_005_val.py
python3 TEST_006.py
python3 TEST_006_val.py
# python3 TEST_007.py
# python3 TEST_007_val.py
python3 TEST_008.py
python3 TEST_008_val.py
