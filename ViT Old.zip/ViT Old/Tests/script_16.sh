#!/bin/bash

# Author: A.M.Kharazi
# License: BSD 3 clause

# Comment test cases you wish not to run, then run the bash file

python3 TEST_121.py
python3 TEST_121_val.py
python3 TEST_122.py
python3 TEST_122_val.py
python3 TEST_123.py
python3 TEST_123_val.py
python3 TEST_124.py
python3 TEST_124_val.py
python3 TEST_125.py
python3 TEST_125_val.py
python3 TEST_126.py
python3 TEST_126_val.py
python3 TEST_127.py
python3 TEST_127_val.py
python3 TEST_128.py
python3 TEST_128_val.py
