#!/bin/bash

# Author: A.M.Kharazi
# License: BSD 3 clause

# Comment test cases you wish not to run, then run the bash file

python3 TEST_049.py
python3 TEST_049_val.py
python3 TEST_050.py
python3 TEST_050_val.py
python3 TEST_051.py
python3 TEST_051_val.py
python3 TEST_052.py
python3 TEST_052_val.py
python3 TEST_053.py
python3 TEST_053_val.py
python3 TEST_054.py
python3 TEST_054_val.py
python3 TEST_055.py
python3 TEST_055_val.py
python3 TEST_056.py
python3 TEST_056_val.py
