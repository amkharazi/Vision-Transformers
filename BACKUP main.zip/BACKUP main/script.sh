# python train.py --run_id ID056_vit_tiny_tensorized_dummy_test_stl10 --model_type tensorized --dataset stl10 --batch_size 256 --epochs 600 --image_size 32 --patch_size 4 --num_classes 10 --num_layers 6 --num_heads 2 2 2 --embed_dim 4 4 4 --mlp_dim 4 4 8 --tensor_method_mlp tp tle --tensor_method tle --reduce_level 0 0 0

# python train.py --run_id ID040_vit_tiny_tensorized_dummy_test_stl10 --model_type tensorized --dataset stl10 --batch_size 256 --epochs 600 --image_size 32 --patch_size 4 --num_classes 10 --num_layers 6 --num_heads 2 2 2 --embed_dim 4 4 4 --mlp_dim 4 4 8 --tensor_method_mlp tdle tdle --tensor_method tdle --reduce_level 0 0 0

